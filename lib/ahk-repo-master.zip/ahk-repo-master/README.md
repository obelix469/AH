Menixator's ahk-repo
========

A collection of autohotkey scripts authored by me.


##Running the scripts.
- Download an install [Autohotkey](http://www.autohotkey.com)
- Open up the script.
